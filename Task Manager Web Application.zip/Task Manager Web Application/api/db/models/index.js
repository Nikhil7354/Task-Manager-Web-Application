const { List } = require('./list.model');
const { Task } = require('./task.model');
const { User } = require('./user.model');


module.exports = {
    List,
    Task,
    User
}